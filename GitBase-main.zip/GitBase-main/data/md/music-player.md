---
title: 'I Create A Musci Player '
description: Use Claude
date: '2025-01-09T07:23:18.962Z'
---
I Create A   [Musci Player](https://musicplayer-olive.vercel.app/)
